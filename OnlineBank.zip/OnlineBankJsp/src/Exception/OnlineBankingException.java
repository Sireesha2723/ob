package Exception;

public class OnlineBankingException extends Exception{
	public OnlineBankingException(String msg){
		super(msg);
	}
}
